﻿using backend.DTOs;
using backend.Services;
using Microsoft.AspNetCore.Mvc;

namespace backend.Controllers
{
    [ApiController]
    [Route("api/boards")]
    public class BoardsController : ControllerBase
    {
        private readonly BoardService _service;

        public BoardsController(BoardService service)
        {
            _service = service;
        }

        [HttpGet]
        public IActionResult GetAll()
            => Ok(_service.GetAll());

        [HttpGet("{id}")]
        public IActionResult GetById(Guid id)
        {
            var board = _service.GetById(id);
            return board == null ? NotFound() : Ok(board);
        }

        [HttpPost]
        public IActionResult Create([FromBody] CreateBoardDto dto)
        {
            var board = _service.Create(dto);
            return Ok(board);
        }
    }
}