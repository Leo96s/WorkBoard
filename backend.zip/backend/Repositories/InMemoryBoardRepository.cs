﻿using backend.Model;
using backend.Models;

namespace backend.Repositories
{
    public class InMemoryBoardRepository : IBoardRepository
    {
        private readonly List<Board> _boards = new();

        public InMemoryBoardRepository()
        {
            // 🔥 BOARD DEFAULT AQUI
            var defaultBoard = new Board
            {
                Id = Guid.NewGuid(),
                Name = "Default Board",
                Columns = new List<BoardColumn>
                {
                    new BoardColumn { Id = Guid.NewGuid(), Name = "A Fazer", Order = 1 },
                    new BoardColumn { Id = Guid.NewGuid(), Name = "Em Curso", Order = 2 },
                    new BoardColumn { Id = Guid.NewGuid(), Name = "Concluído", Order = 3 }
                }
            };

            _boards.Add(defaultBoard);
        }

        public IEnumerable<Board> GetAll()
        {
            return _boards;
        }

        public Board? GetById(Guid id)
        {
            return _boards.FirstOrDefault(b => b.Id == id);
        }

        public void Add(Board board)
        {
            _boards.Add(board);
        }
    }
}