﻿using backend.DTOs;
using backend.Models;
using backend.Repositories;

namespace backend.Services
{
    public class BoardService
    {
        private readonly IBoardRepository _boardRepository;
        private readonly IBoardColumnRepository _columnRepository;

        public BoardService(IBoardRepository boardRepository, IBoardColumnRepository columnRepository)
        {
            _boardRepository = boardRepository;
            _columnRepository = columnRepository;

            // Criar colunas por defeito para o board inicial
            var defaultBoardId = Guid.Parse("00000000-0000-0000-0000-000000000001");
            var defaultColumns = new[]
            {
                new BoardColumn { Id = Guid.NewGuid(), Name = "A Fazer",   Color = "#3B82F6", Order = 1, BoardId = defaultBoardId },
                new BoardColumn { Id = Guid.NewGuid(), Name = "Em Curso",  Color = "#F59E0B", Order = 2, BoardId = defaultBoardId },
                new BoardColumn { Id = Guid.NewGuid(), Name = "Concluído", Color = "#10B981", Order = 3, BoardId = defaultBoardId },
            };
            foreach (var col in defaultColumns)
                _columnRepository.Add(col);
        }

        public IEnumerable<BoardDto> GetAll()
            => _boardRepository.GetAll().Select(ToDto);

        public BoardDto? GetById(Guid id)
        {
            var board = _boardRepository.GetById(id);
            return board == null ? null : ToDto(board);
        }

        public BoardDto Create(CreateBoardDto dto)
        {
            var board = new Board { Name = dto.Name };
            _boardRepository.Add(board);
            return ToDto(board);
        }

        public void Delete(Guid id) => _boardRepository.Delete(id);

        public ColumnDto AddColumn(CreateColumnDto dto)
        {
            var existing = _columnRepository.GetByBoardId(dto.BoardId);
            var order = existing.Any() ? existing.Max(c => c.Order) + 1 : 1;

            var column = new BoardColumn
            {
                Name = dto.Name,
                Color = dto.Color,
                BoardId = dto.BoardId,
                Order = order
            };

            _columnRepository.Add(column);
            return ToColumnDto(column);
        }

        public ColumnDto? UpdateColumn(Guid columnId, UpdateColumnDto dto)
        {
            var column = _columnRepository.GetById(columnId);
            if (column == null) return null;

            column.Name = dto.Name;
            column.Color = dto.Color;
            _columnRepository.Update(column);
            return ToColumnDto(column);
        }

        public bool DeleteColumn(Guid columnId)
        {
            var column = _columnRepository.GetById(columnId);
            if (column == null) return false;
            _columnRepository.Delete(columnId);
            return true;
        }

        private BoardDto ToDto(Board board) => new()
        {
            Id = board.Id,
            Name = board.Name,
            Columns = _columnRepository.GetByBoardId(board.Id).Select(ToColumnDto).ToList()
        };

        private static ColumnDto ToColumnDto(BoardColumn col) => new()
        {
            Id = col.Id,
            Name = col.Name,
            Color = col.Color,
            Order = col.Order,
            BoardId = col.BoardId
        };
    }
}

